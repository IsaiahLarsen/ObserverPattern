package program2;

import java.util.ArrayList;

public interface Observer {
    void update(ArrayList snap);
}
