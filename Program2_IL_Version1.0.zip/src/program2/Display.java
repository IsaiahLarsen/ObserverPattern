package program2;

//Display Interface
//@params NONE
public interface Display {
    public void display();
}
